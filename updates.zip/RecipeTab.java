import javafx.scene.control.Tab;
import javafx.scene.web.HTMLEditor;
import javafx.scene.control.ToolBar;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

/**
 * Where the recipe is created, edited, deleted, and favorited.
 * Created by dillon on 9/29/16.
 */
class RecipeTab extends Tab {

	/** The current recipe object */
    private Recipe recipe = new Recipe();
    
    /** Determines if the recipe can be edited */
    private boolean isRecipeEditable;
    
    /** The format of the tab */
    private VBox layout = new VBox();
    
    /** WHere the buttons are housed */
    private ToolBar toolBar = new ToolBar();
    
    /** Where the user enters recipe's name */
    private TextField titleField = new TextField();
    
    /** Click to enable editing */
    private Button editButton = new Button();
    
    /** Click to delete recipe from the database */
    private Button deleteButton = new Button("Delete");
    
    /** Adds current recipe to personal cookbook. */
    private Button favoriteButton = new Button("Favorite");
    
    /** Where the user enter the ingredients and instructions */
    private HTMLEditor editor = new HTMLEditor();
    
    /** To write the recipe to a file */
    private PrintWriter writer; 
    
    /** File to store favorite recipes */
    File cookbook = new File("./cookbook.txt");
    
    /**
     * Constructor to create a new RecipeTab that accepts a new recipe
     * for the database.
     * @throws SQLException
     */
    RecipeTab() throws SQLException {
        super("New Recipe");

        titleField.setPromptText("New Recipe");

        editor.setHtmlText("<html dir=\"ltr\"><head></head><body contenteditable=\"true\"><h1><font face=\"Lucida Grande\" size=\"6\">New Recipe</font></h1><h2><font face=\"Lucida Grande\" size=\"5\">Ingredients</font></h2><p><ul><li><font face=\"Lucida Grande\">Add ingredients...</font></li></ul><h2><font face=\"Lucida Grande\" size=\"5\">Instructions</font></h2><p><ol><li><font face=\"Lucida Grande\">Start typing...</font></li></ol></p></p></body></html>");

        editButton.setText("Save");
        editButton.setOnAction(a -> {
            try {
                saveNewRecipe();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        });

        setup();
    }

    /**
     * Constructor to create a new RecipeTab that displays an
     * existing recipe in the database.
     * @param recipe an existing recipe to display
     */
    RecipeTab(Recipe recipe) throws SQLException {
        super(recipe.getTitle());

        this.recipe = recipe;

        titleField.setText(recipe.getTitle());
        editor.setHtmlText(recipe.getText());

        try {
            setRecipeEditable(false);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        setup();
    }

    /**
     * Sets up the file writer and button actions
     * @throws SQLException
     */
    private void setup() throws SQLException {
    	
    	try {
			if(cookbook.createNewFile()){
				System.out.println("File created");
				writer = new PrintWriter(new BufferedWriter(new FileWriter(cookbook, true)));
				writer.println("My Cookbook");
			} else {
				System.out.println("File exists");
				writer = new PrintWriter(new BufferedWriter(new FileWriter(cookbook, true)));
			}
			
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
    	
        deleteButton.setOnAction(a -> {
            try {
                delete();
            } catch (SQLException e) {}
        });

        
        favoriteButton.setOnAction(a -> {
	    	//Printing the recipe's information to the file
	    	fWrite();
        		
        });
        
        toolBar.getItems().addAll(titleField, editButton, favoriteButton, deleteButton);
        layout.getChildren().addAll(toolBar, editor);

        setContent(layout);
    }

    /**
     * Determines whether the recipe is view-only or editable by the user.
     */
    private void setRecipeEditable(boolean editable) throws SQLException {
        if (editable) {
            isRecipeEditable = true;
            titleField.setDisable(false);
            editor.setDisable(false);

            editButton.setText("Save Changes");
            editButton.setOnAction(a -> {
                try {
                    saveChanges();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            });
        } else {
            isRecipeEditable = false;
            titleField.setDisable(true);
            editor.setDisable(true);

            editButton.setText("Edit");
            editButton.setOnAction(a -> {
                try {
                    setRecipeEditable(true);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            });
        }
    }

    /**
     * Saves the recipe object to the database
     * @throws SQLException
     */
    private void saveNewRecipe() throws SQLException {
        try {
            setRecipeEditable(false);

            String title;
            if (titleField.getText() == "") {
                title = "New Recipe";
            } else {
                title = titleField.getText();
            }

            if (Recipro.connectsToPrivateServer()) {
                Connect.add(title, editor.getHtmlText());
            } else {
                HerokuConnect.add(title, editor.getHtmlText());
            }

            setText(titleField.getText());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Updates the edits that have been made to the recipe
     * @throws SQLException
     */
    private void saveChanges() throws SQLException {
        try {
            setRecipeEditable(false);

            if (Recipro.connectsToPrivateServer()) {
                Connect.update(recipe.getIndex(), titleField.getText(), editor.getHtmlText());
            } else {
                HerokuConnect.update(recipe.getIndex(), titleField.getText(), editor.getHtmlText());
            }

            setText(titleField.getText());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Prompts the User whether or not to delete the open Recipe.
     * If confirmed, the Record is deleted (if it exists) and this Tab is closed.
     */
    private void delete() throws SQLException {
        // TODO Add a prompt.
        try {
            if (Recipro.connectsToPrivateServer()) {
                Connect.delete(recipe.getIndex());
            } else {
                HerokuConnect.delete(recipe.getIndex());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        getTabPane().getTabs().removeAll(this);
    }
    
    /**
     * Writes the recipe's information to the text file.
     */
    private void fWrite() {
    	System.out.println("writing");
    	writer.append('-');
    	writer.println("");
    	writer.println(recipe.getTitle());	
    	writer.println(recipe.getText());
    	writer.println("END OF RECIPE");
    	writer.flush();
    }
    
    /** 
     * Gets the file path of the cookbook text document
     * @return the file path to the cookbook.txt
     */
    public File getCookbook(){
		return cookbook;
    	
    }
}
