import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Scanner;

import javafx.scene.control.Tab;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

/**
 * Where the user can view the recipes they selected as favorites.
 * @author Marc Betancourt
 *
 */
public class CookbookTab extends Tab{
	/** The format of the tab */
	private VBox layout = new VBox();
	/** Where the text will be displayed */
	private TextArea textArea;
	
	
	/**
	 * Default constructor
	 */
	CookbookTab(){
		super("My Cookbook");
		
		setup();
		display();
	}
	
	/**
	 * Creates the text area and formats it. 
	 * Adds the textArea to the layout of the tab
	 */
	private void setup(){
		textArea = new TextArea();
		textArea.setFont(Font.font("SanSerif", 16));
		textArea.setEditable(false);
		textArea.setMinHeight(700);
		
		layout.getChildren().add(textArea);
		
		setContent(layout);
	}
	
	/**
	 * Scans the cookbook text file and adds the content to the textArea
	 */
	@SuppressWarnings("resource")
	private void display(){
		try{
			FileReader reader = new FileReader("./cookbook.txt");
			BufferedReader buffReader = new BufferedReader(reader);
			StringBuffer sBuff = new StringBuffer();
			String line;
			while((line = buffReader.readLine()) != null) {
				sBuff.append(line + "\n");
			}
			reader.close();
			String output = sBuff.toString();
			textArea.appendText(output);
			
		} catch (Exception e){
			e.printStackTrace();
		}
		
	}
	
}
