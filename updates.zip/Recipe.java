/**
 * The index, title, and instructions for the recipe.
 * Created by dillon on 9/19/16.
 */
public class Recipe {
	/** unique ID for the database */
    private String index;
    /** recipe name */
    private String title;
    /** recipe ingredients and instructions */
    private String text;

    /**
     * Default constructor 
     */
    public Recipe() {}

    /**
     * Constructor given the following parameters:
     * @param index
     * @param title
     * @param text
     */
    public Recipe(String index, String title, String text) {
        this.index = index;
        this.title = title;
        this.text = text;
    }

    /**
     * 
     * @return ID
     */
    public String getIndex() {
        return index;
    }

    /**
     * 
     * @return name
     */
    public String getTitle() {
        return title;
    }

    /**
     * 
     * @return ingredients and instructions
     */
    public String getText() {
        return text;
    }
}

