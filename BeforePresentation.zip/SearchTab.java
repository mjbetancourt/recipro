import javafx.scene.control.*;
import javafx.scene.control.TableColumn.*;
import javafx.collections.*;
import javafx.beans.value.*;
import javafx.beans.property.*;
import javafx.util.Callback;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.scene.control.cell.PropertyValueFactory;

/**
 * Displays the results of a search in a table.
 * Table items can be clicked on to select.
 * Created by Dillon Fagan on 9/29/16.
 */
class SearchTab extends Tab {

	/** What to search for */
    private String query = "GET_ALL";

    /** Displays Results of a Database Query. */
    private TableView<Recipe> table = new TableView<>();

    /** Results of a Query; the Contents of the TableView. */
    private ObservableList<Recipe> rowData = FXCollections.observableArrayList();

    /**
     * Default Constructor. Fetches all Recipes from the Database and
     * displays them in a Table.
     * @throws SQLException
     */
    
    
    SearchTab() throws SQLException {
        super("Searching...");

        try {
            if (Recipro.connectsToPrivateServer()) {
                rowData = Connect.getAll();
            } else {
                rowData = HerokuConnect.getAll();
            }

            setup();
        } catch (SQLException e) {
            System.out.println("Could not connect to database.");
        }
    }

    
    /**
     * Fetches all Recipes that are similar to a given String of Keywords
     * and displays them in a Table.
     * @param s
     * @throws SQLException
     */
    SearchTab(String s) throws SQLException {
        super("Searching...");

        try {
            if (Recipro.connectsToPrivateServer()) {
                rowData = Connect.getByKeyword(s);
            } else {
                rowData = HerokuConnect.getByKeyword(s);
            }

            setup();
        } catch (SQLException e) {
            System.out.println("Could not connect to database.");
        }
    }

    SearchTab(File f) throws SQLException{
    	super("My Cookbook");
    	
    	String query = read(f);
    	ArrayList<String> indices = new ArrayList<>();
    	for (String index : query.split(",")) {
    		if(index != "BEGIN") indices.add(index);
        }
    	
    	try {
    		for (String index : indices) {
        		Recipe r = Connect.getRecipe(index);        		
        		rowData.add(r);
        	}
    		
    		setup();
    	} catch (Exception e){    	}
    	
    	setText("My cookbook");
    	
    }
    /**
     * Sets up the UI for the Tab.
     * @throws SQLException
     */
    private void setup() throws SQLException {
        TableColumn recipeColumn = new TableColumn("Recipe");
        recipeColumn.setMinWidth(300);
        recipeColumn.setCellValueFactory(new PropertyValueFactory<>("title"));

        setContent(table);

        // Fetch the Recipe Object from a selected Row and throw into a RecipeTab.
        table.setRowFactory(t -> {
            TableRow<Recipe> row = new TableRow<>();
            row.setOnMouseClicked(e -> {
                if (e.getClickCount() == 2 && (!row.isEmpty())) {
                    try {
                        Recipe r;
                        if (Recipro.connectsToPrivateServer()) {
                            r = Connect.getRecipe(row.getItem().getIndex());
                        } else {
                            r = HerokuConnect.getRecipe(row.getItem().getIndex());
                        }

                        RecipeTab newRecipeTab = new RecipeTab(r);
                        getTabPane().getTabs().addAll(newRecipeTab);
                        getTabPane().getSelectionModel().select(newRecipeTab);
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            });

            return row ;
        });

        
       
    	
        // Add the Recipe Column to the Table.
        table.getColumns().addAll(recipeColumn);

        // Add the retrieved Data to the Table.
        table.setItems(rowData);

        // Update the Tab's Title with the Number of Results.
        setText(String.valueOf(table.getItems().size()) + " Recipes Found");
    }
    
    /**
	 * Scans the cookbook text file and adds the content to the textArea
	 */
	private String read(File f) {
		
		String output = "";
		
		try{
			FileReader reader = new FileReader(f);
			BufferedReader buffReader = new BufferedReader(reader);
			StringBuffer sBuff = new StringBuffer();
			String line;
			while((line = buffReader.readLine()) != null) {
				sBuff.append(line + "\n");
			}
			reader.close();
			output = sBuff.toString();
			//textArea.appendText(output);
			
		} catch (Exception e){
			e.printStackTrace();
		}
		
		return output;
	}
}
