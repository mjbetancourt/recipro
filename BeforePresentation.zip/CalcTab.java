import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.CheckMenuItem;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Tab;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

/**
 * Simple conversion calculator to assist user in the cooking process.
 * Converts between metric and english units of volume.
 * @author Marc Betancourt
 *
 */
public class CalcTab extends Tab {

	TextField input;
	
	TextField tDisplay;
	TextField oDisplay;
	TextField cDisplay;
	TextField qDisplay;
	TextField lDisplay;
	
	private ObservableList<CheckMenuItem> units = FXCollections.observableArrayList();
	
	/**
	 * Sets up the tab with multiple layers of layouts and creates all the fields, buttons, and labels
	 */
	CalcTab() {
		super("Unit Conversion");
		
		// Primary layout for the tab
        VBox primaryLayout = new VBox();
        primaryLayout.setPadding(new Insets(20, 20, 20, 20));
        primaryLayout.setSpacing(20);
        primaryLayout.setAlignment(Pos.TOP_CENTER);
        primaryLayout.setBackground(new Background(new BackgroundFill(Color.WHITE, CornerRadii.EMPTY, Insets.EMPTY)));
        
        // Secondary layout to house input and submit button
        HBox secondaryLayout = new HBox();
        secondaryLayout.setSpacing(40);
        secondaryLayout.setAlignment(Pos.CENTER);
        
        VBox valueLayout = new VBox();
        valueLayout.setSpacing(15);
        valueLayout.setAlignment(Pos.CENTER);
        
        VBox labelLayout = new VBox();
        labelLayout.setSpacing(25);
        labelLayout.setAlignment(Pos.CENTER);
        
        HBox tertiaryLayout = new HBox();
        tertiaryLayout.setSpacing(5);
        tertiaryLayout.setAlignment(Pos.CENTER);
        input = new TextField();
        
        MenuButton menuButton = new MenuButton("Units");
        CheckMenuItem tUnit = new CheckMenuItem("Tablespoons");
        CheckMenuItem oUnit = new CheckMenuItem("Fl. Ounces");
        CheckMenuItem cUnit = new CheckMenuItem("Cups");
        CheckMenuItem qUnit = new CheckMenuItem("Quarts");
        CheckMenuItem lUnit = new CheckMenuItem("Liters");
        units.addAll(tUnit,oUnit,cUnit,qUnit,lUnit);
        menuButton.getItems().addAll(units);
        
        tDisplay = new TextField();
        tDisplay.setPrefWidth(70);
        oDisplay = new TextField();
        oDisplay.setPrefWidth(70);
        cDisplay = new TextField();
        cDisplay.setPrefWidth(70);
        qDisplay = new TextField();
        qDisplay.setPrefWidth(70);
        lDisplay = new TextField();
        lDisplay.setPrefWidth(70);
        
        Label t = new Label("Tablespoons");
        Label o = new Label("Fluid Ounces");
        Label c = new Label("Cups");
        Label q = new Label("Quarts");
        Label l = new Label("Liters");
        
        
        
        Button convertButton = new Button("Convert");
        
        convertButton.setOnAction(a -> {
        	String sVal = input.getText();
        	Double val = Double.parseDouble(sVal);
        	String unit = null; 
        	
        	for(MenuItem item : menuButton.getItems()) {
                CheckMenuItem checkMenuItem = (CheckMenuItem) item;
                if(checkMenuItem.isSelected()) {
                    unit = checkMenuItem.getText();
                }
            }
        	
        	convert(val, unit);
        	
        });
        
        //Add all items to the tertiary layout
        valueLayout.getChildren().addAll(tDisplay, oDisplay, cDisplay, qDisplay, lDisplay);
        labelLayout.getChildren().addAll(t, o, c, q, l);
        tertiaryLayout.getChildren().addAll(valueLayout, labelLayout);
        // Add all items to the secondary layout
        secondaryLayout.getChildren().addAll(input, menuButton);

        // Add all items to the primary layout
        primaryLayout.getChildren().addAll(secondaryLayout, convertButton, tertiaryLayout);

        // Set primary layout as the content of the tab
        setContent(primaryLayout);
	}

	/**
	 * Handles the calculations for the tab
	 * @param val
	 * @param unit
	 */
	private void convert(Double val, String unit) {
		Double t = 0.;
		Double o = 0.;
		Double c = 0.;
		Double q = 0.;
		Double l = 0.;
		
		if(unit == "Tablespoons"){
			t = val;
			o = val * .5;
			c = val * .0625;
			q = val * .015625;
			l = val * .0147868;
		} else if(unit == "Fl. Ounces"){
			t = val * 2;
			o = val;
			c = val * .123223;
			q = val * .03125;
			l = val * .0295735;
		} else if(unit == "Cups"){
			t = val * 16;
			o = val * 8.11537;
			c = val;
			q = val * 4;
			l = val * .24;
		} else if(unit == "Quarts"){
			t = val * 64;
			o = val * 32;
			c = val * 3.94314;
			q = val;
			l = val * .946353;
		} else if(unit == "Liters"){
			t = val * 67.627;
			o = val * 33.814;
			c = val * 4.16667;
			q = val * 1.05669;
			l = val;
		}
	
		String st = t.toString();
		String so = o.toString();
		String sc = c.toString();
		String sq = q.toString();
		String sl = l.toString();
		
		fillGrid(st,so,sc,sq,sl);
	}
	
	/**
	 * Displays the converted info
	 * @param t
	 * @param o
	 * @param c
	 * @param q
	 * @param l
	 */
	private void fillGrid(String t, String o, String c, String q, String l) {
		tDisplay.setText(t);
		oDisplay.setText(o);
		cDisplay.setText(c);
		qDisplay.setText(q);
		lDisplay.setText(l);
		
		
	}
	
	
}
