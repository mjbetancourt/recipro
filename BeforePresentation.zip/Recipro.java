import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

/**
 * The main class
 * Created by Dillon Fagan on 9/13/16.
 */
public class Recipro extends Application {

    /**
     * The TabPane stores and manages all open tabs.
     */
    private TabPane tabs;
    
    /** File to store favorite recipes */
    static File cookbook = new File("recipro.txt");

    /**
	 * @return the cookbook
	 */
	public static File getCookbook() {
		return cookbook;
	}

	/**
	 * @param cookbook the cookbook to set
	 */
	public static void setCookbook(File cookbook) {
		Recipro.cookbook = cookbook;
	}

	/**
     * Determines whether to connect to the Heroku PostgreSQL DB or
     * a private Database.
     */
    private static boolean privateServer = true;

    /**
     * Main method required for executable file
     * @param args
     */
    public static void main(String[]args) {
    	launch(args);
    }

    /**
     * Initializes a new Stage as the main window.
     */
    @Override
    public void start(Stage primaryStage) throws SQLException {
        // Primary layout for the window
        VBox rootLayout = new VBox();

        // Set up the window
        primaryStage.setTitle("Recipro");
        primaryStage.setScene(new Scene(rootLayout, 1024, 768));
        primaryStage.setMaximized(true);

        // Initialize the tab manager and add a HomeTab
        tabs = new TabPane();
        tabs.setPrefSize(3840, 2160);
        tabs.getTabs().add(new HomeTab());

        try {
            // Add all items to the root layout
            rootLayout.getChildren().addAll(createMenuBar(), tabs);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
			if(cookbook.createNewFile()){
				String user = System.getProperty("user.name");
				String path = "C:/Users/" + user + "/Documents/Recipro/cookbook.txt";
				cookbook = new File(path);
				cookbook.mkdir();
				System.out.println("File created");
				PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(cookbook, true)));
	    		writer.print("BEGIN");
			} else {
				System.out.println("File exists");
				
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
        
        // Show the window
        primaryStage.show();
    }

    /**
     * Returns a completed MenuBar for the window.
     */
    private MenuBar createMenuBar() throws SQLException {
        MenuBar menuBar  = new MenuBar();

        // File Menu
        Menu fileMenu = new Menu("File");

        MenuItem newRecipeCommand = new MenuItem("New Recipe...");
        newRecipeCommand.setOnAction(a -> {
            try {
                RecipeTab newRecipeTab = new RecipeTab();
                tabs.getTabs().add(newRecipeTab);
                tabs.getSelectionModel().select(newRecipeTab);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        });

        MenuItem serverConnectionCommand = new MenuItem("Connect to Heroku Server");
        serverConnectionCommand.setOnAction(a -> {
            privateServer = !privateServer;

            // TODO Close all tabs?
            tabs.getTabs().removeAll();

            // Toggle the Label of the serverConnectionCommand
            if (privateServer) {
                serverConnectionCommand.setText("Connect to Heroku");
            } else {
                serverConnectionCommand.setText("Connect to SQL Server");
            }
        });

        fileMenu.getItems().addAll(newRecipeCommand, serverConnectionCommand);

        // Tools Menu
        Menu toolsMenu = new Menu("Tools");

        MenuItem calcCommand = new MenuItem("Conversion Assistant");
        calcCommand.setOnAction(a -> {
    		CalcTab newCalcTab = new CalcTab();
    		tabs.getTabs().add(newCalcTab);
    		tabs.getSelectionModel().select(newCalcTab);
        });

        toolsMenu.getItems().add(calcCommand);

        menuBar.getMenus().addAll(fileMenu, toolsMenu);

        return menuBar;
    }

    public static boolean connectsToPrivateServer() {
        return privateServer;
    }
}
